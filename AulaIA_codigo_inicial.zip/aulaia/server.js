const express = require('express');
const multer = require('multer');
const OpenAI = require('openai');
const pdf = require('pdf-parse');
const path = require('path');

const app = express();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 8 * 1024 * 1024, files: 1 },
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'application/pdf' || file.originalname.toLowerCase().endsWith('.pdf')) cb(null, true);
    else cb(new Error('Solo se permiten archivos PDF.'));
  }
});
app.use(express.static(path.join(__dirname, 'public')));
app.get('/api/health', (req, res) => res.json({ ok: true, app: 'AulaIA' }));

app.post('/api/chat', upload.single('pdf'), async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: 'El tutor IA aún no está configurado. Falta añadir OPENAI_API_KEY en el servidor.' });
    }
    const question = (req.body.question || '').trim();
    if (!question) return res.status(400).json({ error: 'Escribe una pregunta.' });
    if (question.length > 5000) return res.status(400).json({ error: 'La pregunta es demasiado larga.' });

    let documentText = '';
    if (req.file) {
      const parsed = await pdf(req.file.buffer);
      documentText = (parsed.text || '').slice(0, 24000);
      if (!documentText.trim()) return res.status(400).json({ error: 'No pude extraer texto del PDF. Si es un escaneo, necesitará reconocimiento OCR.' });
    }
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const prompt = [
      'Eres el tutor educativo de AulaIA. Responde en español claro y amable.',
      'Ayuda a estudiantes de secundaria y universidad. Explica paso a paso, enseña el razonamiento y no inventes fuentes.',
      'Si no sabes algo, dilo. En tareas académicas, prioriza enseñar y no solo dar la respuesta.',
      documentText ? `El estudiante ha subido un PDF. Usa este texto como material de referencia y señala si no contiene la respuesta.\n\n--- INICIO DEL TEXTO DEL PDF ---\n${documentText}\n--- FIN DEL TEXTO DEL PDF ---` : '',
      `Pregunta del estudiante: ${question}`
    ].filter(Boolean).join('\n\n');

    const completion = await client.chat.completions.create({
      model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
      messages: [{ role: 'system', content: 'Eres AulaIA, un tutor educativo útil, honesto y cuidadoso.' }, { role: 'user', content: prompt }],
      max_tokens: 1000
    });
    const answer = completion.choices?.[0]?.message?.content;
    res.json({ answer: answer || 'No pude generar una respuesta. Inténtalo de nuevo.' });
  } catch (err) {
    console.error('AulaIA API error:', err.message);
    if (err.code === 'LIMIT_FILE_SIZE') return res.status(413).json({ error: 'El PDF supera el límite de 8 MB.' });
    res.status(500).json({ error: 'Ocurrió un problema al responder. Revisa la configuración del servidor e inténtalo otra vez.' });
  }
});

app.use((err, req, res, next) => {
  if (err instanceof multer.MulterError && err.code === 'LIMIT_FILE_SIZE') return res.status(413).json({ error: 'El PDF supera el límite de 8 MB.' });
  if (err) return res.status(400).json({ error: err.message || 'Solicitud no válida.' });
  next();
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`AulaIA está funcionando en el puerto ${port}`));
