# AulaIA — primera versión

AulaIA es un prototipo de sitio educativo para secundaria y universidad. Incluye un diseño adaptable a celular, herramientas de inicio rápido, un tutor IA conectado desde el servidor y lectura básica de texto de archivos PDF.

## Importante
- La clave de OpenAI debe guardarse como variable secreta del servidor (`OPENAI_API_KEY`). Nunca la pongas en `public/index.html`.
- El uso de la API de IA puede tener costo y requiere una cuenta/API con acceso y facturación configurados. Una suscripción de ChatGPT no incluye automáticamente saldo para la API.
- Esta primera versión no incluye cuentas de estudiantes, base de datos, límites por usuario ni publicidad. Antes de abrirla al público, añade protección contra abuso y límites de uso.
- Los PDF escaneados como imágenes no se leerán sin OCR. El texto extraído se limita para controlar costos.
- No subas datos personales sensibles ni documentos privados de otras personas.

## Archivos
- `public/index.html`: página y diseño.
- `server.js`: servidor y conexión segura con la API.
- `package.json`: dependencias.
- `.env.example`: ejemplo de variable secreta (no contiene una clave real).

## Publicación
Este proyecto necesita un servicio que ejecute Node.js. Pasos generales:
1. Sube los archivos a un repositorio privado de GitHub.
2. Crea un servicio web Node.js en una plataforma de alojamiento compatible.
3. Configura el comando de inicio como `npm start`.
4. Añade `OPENAI_API_KEY` como variable de entorno secreta en la configuración del servicio y, si hace falta, `OPENAI_MODEL` con `gpt-4o-mini`.
5. Despliega y prueba la URL pública. La plataforma de alojamiento puede tener límites o costos; verifica sus condiciones vigentes antes de publicar.

## Ejecutar localmente (si tienes ordenador)
1. Instala Node.js 18 o superior.
2. En esta carpeta ejecuta `npm install`.
3. Configura `OPENAI_API_KEY` en el entorno.
4. Ejecuta `npm start` y abre `http://localhost:3000`.

## Próximas mejoras recomendadas
1. Límites de uso y protección contra spam.
2. Política de privacidad y aviso claro sobre el procesamiento de preguntas y PDF.
3. Registro/inicio de sesión solo si realmente es necesario.
4. Publicidad después de tener contenido útil y cumplir políticas de la red publicitaria.
5. Pruebas de accesibilidad, seguridad y costos antes de anunciarla al público.
